$(function () {
    if (!sessionStorage.ttoken || sessionStorage.ttoken == null)
        location.href = "login.html";
    //$("#idSpan").val(sessionStorage.ttoken);
    document.getElementById("idSpan").innerHTML = sessionStorage.ttoken; //membantu untuk keluarkn email dekat nav belah kanan

    var link1 = crossroads.addRoute("/logout", function () {
        sessionStorage.clear();
        location.href = "login.html"
    });

    var link6 = crossroads.addRoute("/timer", function () {
        sessionStorage.clear();
        $("#divTimer").show();
        $("#divHome").hide();
        $("#divNotes").hide();
        $("#divAddNotes").hide();
        $("#divEditNotes").hide();
        $("#divSlide").hide();
        
    });

    var link2 = crossroads.addRoute("", function () {
        $("#divHome").show();
        $("#divSlide").show();
        $("#divNotes").hide();
        $("#divAddNotes").hide();
        $("#divEditNotes").hide();
        $("#divTimer").hide();

    });

    var link4 = crossroads.addRoute("/btnAddNotes", function () {
        $("#divHome").hide();
        $("#divNotes").hide();
        $("#divAddNotes").show();
        $("#divEditNotes").hide();
        $("#divTimer").hide();

    });


    var link3 = crossroads.addRoute("/notes", function () {
        $(".navbar-collapse li").removeClass("active");
        $(".navbar-collapse li a[href='notes']").parent().addClass("active");
        $(".navbar-collapse li a[href='']").parent().addClass("active");
        var email = sessionStorage.ttoken;
        var datalist = "email=" + email;
        $.ajax({
            type: "post",
            url: "http://192.168.1.10:8080/gproject_3/GetNotesData",
            data: datalist,
            cache: false,
            success: function (mydata) {
                var myData = JSON.parse(mydata);
                var lastIndex = myData.length - 1;
                var htmlText = "";
                if (myData[lastIndex].status === 1) {
                    for (var i = 0; i < lastIndex; i++) {
                        htmlText = htmlText + "<tr><td>" + myData[i].id
                            + "</td><td><a href=#viewnotes/" + myData[i].id + "'>" + myData[i].subject
                            + "</a></td><td>" + myData[i].topic
                            + "</td><td>" + myData[i].description
                            + "</td><td>" + myData[i].addedDate
                            + "</td><td><a href ='#delcontact'><span class='glyphicon glyphicon-trash' data-notesid="
                            + myData[i].id
                            + "> </span></a></td></tr>";

                    }

                    $("#tblNotes tbody").html(htmlText);
                }

            },
            error: function () {
                console.log("ajax error!");
                alert("Please contact admin!");

            }
        });
        $("#divHome").hide();
        $("#divNotes").show();
        $("#divAddNotes").hide();
        $("#divEditNotes").hide();
        $("#divSlide").hide();
        $("#divTimer").hide();
        

    });

    $("#frmAddNotes").submit(function (e) {
        e.preventDefault();
        e.stopPropagation();

        var subject = $("#subject").val();
        var topic = $("#topic").val();
        var description = $("#description").val();

        var datalist = "subject=" + subject + "&topic=" + topic + "&description=" + description + "&owneremail=" + sessionStorage.ttoken;
        $.ajax({
            type: "post",
            url: "http://192.168.1.10:8080/gproject_3/AddNotes",
            data: datalist,
            cache: false,
            success: function (mydata) {
                var myData = JSON.parse(mydata);
                if (myData.status === 1) {
                    alert("Add Notes Success!");
                    location.href="#notes";
                    //$("#divNotes").show();
                   $("#divAddNotes").hide();
                    
                }
                else {
                    alert("Add Notes Failed");
                }
            },
            error: function () {
                console.log("ajax error!");
                alert("Please contact admin!");
            }
        });
    });

    var link5 = crossroads.addRoute("/viewnotes/{id}", function (id) {
        //$("#divHome").hide();
        //$("#divNotes").hide();
        //$("#divAddNotes").show();
        var datalist = "id=" + id;
        $.ajax({
            type: "post",
            url: "http://192.168.1.10:8080/gproject_3/GetNotesDataById", // utk servlet
            data: datalist,
            cache: false,
            success: function (mydata) {
                var myData = JSON.parse(mydata);
                if (myData.status === 1) {

                    document.getElementById("subject100").value = myData.subject;
                    document.getElementById("topic100").value = myData.topic;
                    document.getElementById("description100").value = myData.description;
                    document.getElementById("notesid").value = myData.id;

                }
                $("#divHome").hide();
                $("#divNotes").hide();
                $("#divAddNotes").hide();
                $("#divEditNotes").show();
                $("#divTimer").hide();

            },
            error: function () {
                console.log("ajax error!");
                alert("Please contact admin!");
            }

        });
    });


    $("#frmEditNotes").submit(function (e) {
        e.preventDefault();
        e.stopPropagation();

        var subject = $("#subject100").val();
        var topic = $("#topic100").val();
        var description = $("#description100").val();
        var notesid = $("#notesid").val();

        var datalist = "subject=" + subject + "&topic=" + topic + "&description=" + description + "&notesid=" + notesid;
        $.ajax({
            type: "post",
            url: "http://192.168.1.10:8080/gproject_3/UpdateNotesById",
            data: datalist,
            cache: false,
            success: function (mydata) {
                var myData = JSON.parse(mydata);
                if (myData.status === 1) {
                    alert("Update Notes Success!");
                    location.href="#notes";
                    $("#divEditNotes").hide();
                    
                }
                else {
                    alert("Update Notes Failed");
                }
            },
            error: function () {
                console.log("ajax error!");
                alert("Please contact admin!");
            }
        });
    });

    $("#tblNotes tbody").on("click", "span", function () {
        var notesid = $(this).data("notesid")
        //bootbox.alert("Delete Process Index "+notesid);
        datalist = "notesid=" + notesid;
        var parentTR = $(this).parent().parent().parent();
        bootbox.confirm("Are you sure to delete this notes?", function (answer) {
            if (answer) {
                $.ajax({
                    type: "post",
                    url: "http://192.168.1.10:8080/gproject_3/DelNotesById",
                    data: datalist,
                    cache: false,
                    success: function (mydata) {
                        var myData = JSON.parse(mydata);
                        if (myData.status === 1) {
                            alert("Delete Notes Successfull!");
                            $(parentTR).fadeOut("slow", "swing", function () {
                                $(parentTR).remove();
                            });
                        }
                        else {
                            alert("Delete Notes Failed");
                        }
                    },
                    error: function () {
                        console.log("ajax error!");
                        alert("Please contact admin!");
                    }
                });
            } else {
                bootbox.alert("Delete Canceled")
            }

        });
    });

    function parseHash(newHash, oldHash) {
        crossroads.parse(newHash);
    }

    hasher.initialized.add(parseHash);
    hasher.changed.add(parseHash);
    hasher.init();

});

